﻿namespace lBoxItemsForLoan
{
    internal class SelectedIndex
    {
    }
}